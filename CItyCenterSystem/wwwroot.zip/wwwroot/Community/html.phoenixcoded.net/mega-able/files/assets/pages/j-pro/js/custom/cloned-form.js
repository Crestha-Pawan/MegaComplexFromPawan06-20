$(document).ready(function(){

		/***************************************/
		/* Cloned element */
		/***************************************/
		$('.clone-widget').cloneya();

		$('.clone-rightside-btn-1').cloneya();

		$('.clone-rightside-btn-2').cloneya();

		$('.clone-leftside-btn-1').cloneya();

		$('.clone-leftside-btn-2').cloneya();

		$('.clone-link').cloneya();
		/***************************************/
		/* end Cloned element */
		/***************************************/

	});